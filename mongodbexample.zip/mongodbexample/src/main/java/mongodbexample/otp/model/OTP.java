package mongodbexample.otp.model;

import java.time.LocalDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "otp")
public class OTP {
    @Id
    private String id;
    @Indexed(unique = true)
    private String email;
    private String otpCode;
    private int attempts;
    private boolean isLocked;
    private LocalDateTime generatedTime;
    private LocalDateTime lockedUntil;
	
    public OTP() {
    	
    }
	public OTP(String id, String email, String otpCode, int attempts, boolean isLocked, LocalDateTime generatedTime,
			LocalDateTime lockedUntil) {
		super();
		this.id = id;
		this.email = email;
		this.otpCode = otpCode;
		this.attempts = attempts;
		this.isLocked = isLocked;
		this.generatedTime = generatedTime;
		this.lockedUntil = lockedUntil;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getOtpCode() {
		return otpCode;
	}
	public void setOtpCode(String otpCode) {
		this.otpCode = otpCode;
	}
	public int getAttempts() {
		return attempts;
	}
	public void setAttempts(int attempts) {
		this.attempts = attempts;
	}
	public boolean isLocked() {
		return isLocked;
	}
	public void setLocked(boolean isLocked) {
		this.isLocked = isLocked;
	}
	public LocalDateTime getGeneratedTime() {
		return generatedTime;
	}
	public void setGeneratedTime(LocalDateTime generatedTime) {
		this.generatedTime = generatedTime;
	}
	public LocalDateTime getLockedUntil() {
		return lockedUntil;
	}
	public void setLockedUntil(LocalDateTime lockedUntil) {
		this.lockedUntil = lockedUntil;
	}

    // Getters and setters
}