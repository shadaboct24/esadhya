package mongodbexample.otp.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import mongodbexample.otp.dto.OTPRequest;
import mongodbexample.otp.service.OTPService;

@RestController
@RequestMapping("/api/otp")
public class OTPController {

    private final OTPService otpService;

    public OTPController(OTPService otpService) {
        this.otpService = otpService;
    }

    @PostMapping("/generate")
    public String generateOTP(@RequestParam String email) {
        return otpService.generateOTP(email);
    }

    @PostMapping("/validate")
    public String validateOTP(@RequestBody OTPRequest otpRequest) {
        return otpService.validateOTP(otpRequest.getEmail(), otpRequest.getOtpCode());
    }
}
