package mongodbexample.otp.service;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import org.springframework.mail.SimpleMailMessage;
//import org.springframework.mail.javamail.JavaMailSender;
//
//@Service
//public class EmailService {
//	@Autowired
//    private JavaMailSender mailSender;
//
//    /**
//     * Sends an OTP to the specified email.
//     * @param toEmail The recipient's email address.
//     * @param otpCode The OTP code to be sent.
//     */
//    public void sendOTP(String toEmail, String otpCode) {
//        SimpleMailMessage message = new SimpleMailMessage();
//        message.setTo(toEmail);
//        message.setSubject("Your OTP Code");
//        message.setText("Your OTP code is: " + otpCode + "\n\nThis code will expire soon. Please use it promptly.");
//
//        try {
//            mailSender.send(message);
//            System.out.println("OTP email sent successfully to " + toEmail);
//        } catch (Exception e) {
//            System.out.println("Error sending OTP email: " + e.getMessage());
//        }
//    }
//}
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

import java.util.Properties;

@Service
public class EmailService {

    @Value("${spring.mail.host}")
    private String host;

    @Value("${spring.mail.port}")
    private int port;

    @Value("${spring.mail.username}")
    private String username;

    @Value("${spring.mail.password}")
    private String password;

    @Value("${spring.mail.properties.mail.smtp.auth}")
    private String auth;

    @Value("${spring.mail.properties.mail.smtp.starttls.enable}")
    private String starttls;

    private JavaMailSender getJavaMailSender() {
        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
        mailSender.setHost(host);
        mailSender.setPort(port);
        mailSender.setUsername(username);
        mailSender.setPassword(password);

        Properties props = mailSender.getJavaMailProperties();
        props.put("mail.smtp.auth", auth);
        props.put("mail.smtp.starttls.enable", starttls);
        
        return mailSender;
    }

    public void sendSimpleMessage(String to, String subject, String text) {
        JavaMailSender mailSender = getJavaMailSender();
        MimeMessage message = mailSender.createMimeMessage();

        try {
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");
            helper.setFrom(username);
            helper.setTo(to);
            helper.setSubject(subject);
            helper.setText(text, true); // Enable HTML content
            mailSender.send(message);
        } catch (MessagingException e) {
            e.printStackTrace();
            // Add appropriate logging and error handling here
        }
    }

    public static String getEmailVerificationBody(String body) {
        // HTML body for OTP email
        return "<html><body><h1>Email Verification</h1>"
                + "<p>Your Verification Code: <a>" + body + "</a></p>"
                + "</body></html>";
    }

//    public static String getEmailForgotPasswordGenrateBody(String body) {
//        // HTML body for OTP email
//        return "<html><body><h1>Email Verification</h1>"
//                + "<p>Your Genrated id to rest your TDU Password: <a>" + body + "</a></p>"
//                + "</body></html>";
//    }
}