package mongodbexample.otp.service;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import mongodbexample.otp.model.OTP;
import mongodbexample.otp.repository.OTPRepository;
import mongodbexample.otp.util.OTPGenerator;

@Service
public class OTPService {

    private final OTPRepository otpRepository;
    private final EmailService emailService;

    @Value("${otp.maxAttempts:3}")
    private int maxAttempts;

    @Value("${otp.lockingTime:5}") // In minutes
    private int lockingTime;

    @Value("${otp.resendTime:1}") // In minutes
    private int resendTime;

    @Value("${otp.expiryTime:10}") // In minutes
    private int expiryTime;

    public OTPService(OTPRepository otpRepository, EmailService emailService) {
        this.otpRepository = otpRepository;
        this.emailService = emailService;
    }

    /**
     * Generates an OTP, saves it in the database, and sends it via email.
     * @param email The email to which the OTP is to be sent.
     * @return A message indicating OTP generation status.
     */
    public String generateOTP(String email) {
//        Optional<OTP> existingOtpRecord = otpRepository.findByEmail(email);
//
//        // If user has an active OTP that's still valid
//        if (existingOtpRecord.isPresent()) {
//            OTP existingOtp = existingOtpRecord.get();
//            if (existingOtp.getGeneratedTime().plusMinutes(resendTime).isAfter(LocalDateTime.now())) {
//                return "Please wait a while before requesting a new OTP.";
//            }
//
//            // Locking check
//            if (existingOtp.isLocked() && existingOtp.getLockedUntil().isAfter(LocalDateTime.now())) {
//                return "Your account is locked due to too many failed attempts. Please try again later.";
//            }
//        }
//
//        // Generate new OTP and save
//        String otpCode = OTPGenerator.generateOTP(6); // Generates a 6-digit OTP
//        OTP otp = new OTP();
//        otp.setEmail(email);
//        otp.setOtpCode(otpCode);
//        otp.setGeneratedTime(LocalDateTime.now());
//        otp.setAttempts(0);
//        otp.setLocked(false);
//        otp.setLockedUntil(null);
//
//        otpRepository.save(otp);

        // Send OTP via email
        emailService.sendSimpleMessage(email,"OTP " ,"123");
        return "OTP has been generated and sent to your email.";
    }

    /**
     * Validates an OTP.
     * @param email The email associated with the OTP.
     * @param otpCode The OTP code to validate.
     * @return A message indicating validation status.
     */
    public String validateOTP(String email, String otpCode) {
        Optional<OTP> otpRecord = otpRepository.findByEmail(email);

        if (otpRecord.isEmpty()) {
            return "Invalid OTP request.";
        }

        OTP otp = otpRecord.get();

        // Check if OTP is expired
        if (otp.getGeneratedTime().plusMinutes(expiryTime).isBefore(LocalDateTime.now())) {
            otpRepository.delete(otp);
            return "OTP has expired. Please request a new OTP.";
        }

        // Check if account is locked
        if (otp.isLocked() && otp.getLockedUntil().isAfter(LocalDateTime.now())) {
            return "Account is locked due to multiple failed attempts. Try again later.";
        }

        // Validate OTP
        if (otp.getOtpCode().equals(otpCode)) {
            otpRepository.delete(otp); // OTP is valid; delete record
            return "OTP is valid!";
        } else {
            // Increment failed attempt count
            int attempts = otp.getAttempts() + 1;
            otp.setAttempts(attempts);

            // Lock account if max attempts reached
            if (attempts >= maxAttempts) {
                otp.setLocked(true);
                otp.setLockedUntil(LocalDateTime.now().plusMinutes(lockingTime));
            }

            otpRepository.save(otp); // Save updated OTP record
            return "Invalid OTP. Please try again.";
        }
    }
}