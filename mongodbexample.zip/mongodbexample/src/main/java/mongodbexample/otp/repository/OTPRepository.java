package mongodbexample.otp.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import mongodbexample.otp.model.OTP;

public interface OTPRepository extends MongoRepository<OTP, String> {
    Optional<OTP> findByEmail(String email);
}
