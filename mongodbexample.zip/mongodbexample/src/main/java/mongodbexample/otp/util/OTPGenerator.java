package mongodbexample.otp.util;

import java.security.SecureRandom;

public class OTPGenerator {

    private static final String DIGITS = "0123456789";
    private static final SecureRandom random = new SecureRandom();

    /**
     * Generates a random OTP of the specified length.
     * @param length Length of the OTP to be generated.
     * @return A randomly generated OTP.
     */
    public static String generateOTP(int length) {
        if (length <= 0) {
            throw new IllegalArgumentException("OTP length must be greater than zero.");
        }

        StringBuilder otp = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            otp.append(DIGITS.charAt(random.nextInt(DIGITS.length())));
        }

        return otp.toString();
    }
}
