package mongodbexample.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mongodbexample.model.User;
import mongodbexample.repository.UserRepository;

@Service
public class LoginService {
	
	
	@Autowired
    private UserRepository userRepository;

    public User validateUser(String username, String password) {
        // Find the user by username and password
        return userRepository.findByUsernameAndPassword(username, password);
    }
}
